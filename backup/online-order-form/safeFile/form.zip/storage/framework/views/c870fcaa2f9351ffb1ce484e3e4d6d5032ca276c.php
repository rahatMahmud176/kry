 
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?>| KRY INTERNATIONAL</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('/')); ?>assets/images/favicon.ico">

        
        <link href="<?php echo e(asset('/')); ?>assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" type="text/css" />
        <link rel="<?php echo e(asset('/')); ?>stylesheet" href="assets/libs/%40chenfengyuan/datepicker/datepicker.min.css">


        <!-- DataTables -->
        <link href="<?php echo e(asset('/')); ?>assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('/')); ?>assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <!-- Responsive datatable examples -->
        <link href="<?php echo e(asset('/')); ?>assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />     

        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('/')); ?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo e(asset('/')); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo e(asset('/')); ?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" /> 
        
          
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php echo Html::style('assets/css/bootstrap.min.css'); ?>

<?php echo Html::style('assets/css/icons.min.css'); ?>

<?php echo Html::style('assets/css/app.min.css'); ?><?php /**PATH C:\laragon\www\form\resources\views/back-end/includes/style.blade.php ENDPATH**/ ?>