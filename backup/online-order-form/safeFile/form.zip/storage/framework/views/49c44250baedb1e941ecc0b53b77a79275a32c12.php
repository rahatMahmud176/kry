 <!-- JAVASCRIPT -->
 <script src="assets/libs/jquery/jquery.min.js"></script>
 <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="assets/libs/metismenu/metisMenu.min.js"></script>
 <script src="assets/libs/simplebar/simplebar.min.js"></script>
 <script src="assets/libs/node-waves/waves.min.js"></script>

 <script src="assets/libs/select2/js/select2.min.js"></script>
 <script src="assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
 <script src="assets/libs/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
 <script src="assets/libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
 <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
 <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
 <script src="assets/libs/%40chenfengyuan/datepicker/datepicker.min.js"></script>
<!-- twitter-bootstrap-wizard js -->
<script src="assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>

<script src="assets/libs/twitter-bootstrap-wizard/prettify.js"></script>

<!-- form wizard init -->
<script src="assets/js/pages/form-wizard.init.js"></script>
 <!-- form advanced init -->
 <script src="assets/js/pages/form-advanced.init.js"></script>

 <script src="assets/js/app.js"></script>
<?php /**PATH C:\laragon\www\form\resources\views/front-end/includes/script.blade.php ENDPATH**/ ?>