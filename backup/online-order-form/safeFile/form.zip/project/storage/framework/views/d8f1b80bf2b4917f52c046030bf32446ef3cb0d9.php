<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Rahat.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Design & Develop by Rahat Mahmud
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\form\project\resources\views/back-end/includes/footer.blade.php ENDPATH**/ ?>