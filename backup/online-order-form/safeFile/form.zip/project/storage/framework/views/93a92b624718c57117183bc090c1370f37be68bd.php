<link href="<?php echo e(asset('/')); ?>assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/libs/%40chenfengyuan/datepicker/datepicker.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/libs/twitter-bootstrap-wizard/prettify.css">
    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('/')); ?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('/')); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('/')); ?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/css/mystyle.css" id="app-style" rel="stylesheet" type="text/css" />

   <?php /**PATH C:\laragon\www\form\project\resources\views/front-end/includes/style.blade.php ENDPATH**/ ?>