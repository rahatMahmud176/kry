
<?php $__env->startSection('title'); ?>
    Courier Due
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-flex align-items-center justify-content-between">
                <h4 class="mb-0 font-size-18">Data Tables</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                        <li class="breadcrumb-item active">Data Tables</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->



    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                     

                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>SL.</th>
                                <th>Date</th>
                                <th>Order Number</th>
                                <th>Model</th> 
                                <th>Price</th>
                                <th>Advance</th>
                                <th>Zone</th>
                                <th>Amount</th>
                                
                            </tr>
                        </thead>

                        <?php
                            $i = 1;
                            $total = 0;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e(date('d-M-y', strtotime($item->created_at))); ?></td>
                                    <td>KRYINT#00<?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->productName); ?></td> 
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->payAmount); ?></td>
                                    <td class="<?php echo e($item->zone=='outsideDhaka'?'text-danger':'text-success'); ?>"><?php echo e($item->zone=='outsideDhaka'?'Courier':'HD'); ?></td>
                                    <td><?php echo e($due = $item->price - $item->payAmount); ?></td>

                                    
                                </tr>
                                <?php
                                    $total = $total + $due;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Total</td>
                                <td>.</td>
                                <td>.</td>
                                <td>.</td> 
                                <td>.</td> 
                                <td>.</td> 
                                <td colspan="" class="text-right"><strong>TOTAL = </strong></td>
                                <td colspan="" class="">
                                    <strong><?php echo e($total); ?></strong>
                                </td>
                            </tr>
                        </tbody>
                        
                    </table>

                </div>

            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

</div> <!-- container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\form\project\resources\views/back-end/reports/courier-due.blade.php ENDPATH**/ ?>