
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mainContent'); ?>
<div class="container-fluid">

    <!-- start page title -->
 
    <!-- end page title -->
 

    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card plan-box">
                <div class="card-body p-4">
                    <div class="media">
                        <div class="media-body">
                            <h5>All Orders</h5>
                            <p class="text-muted ">All order Here </p>
                        </div>
                        <div class="ml-3">
                            <i class="fas fa-ambulance "></i>
                        </div>
                    </div>
                    <div class="py-4">
                        <h2><sup><small>#</small></sup> <?php echo e($currentMonthOrders); ?>/ <span class="font-size-13">This month</span></h2>
                    </div>
                    <div class="text-center plan-btn">
                        <a href="#" class="btn btn-primary btn-sm waves-effect waves-light">Show Here</a>
                    </div>

                     
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card plan-box">
                <div class="card-body p-4">
                    <div class="media">
                        <div class="media-body">
                            <h5>Confirmed Orders</h5>
                            <p class="text-muted">Comfirm orders here</p>
                        </div>
                        <div class="ml-3">
                            <i class="fas fa-check-double text-success"></i>
                        </div>
                    </div>
                    <div class="py-4">
                        <h2><sup><small>#</small></sup> <?php echo e($currentMonthConfirmOrders); ?>/ <span class="font-size-13">This month</span></h2>
                    </div>
                    <div class="text-center plan-btn">
                        <a href="#" class="btn btn-primary btn-sm waves-effect waves-light">Show Here</a>
                    </div> 
                     
                </div>
            </div>
        </div>


        <div class="col-xl-3 col-md-6">
            <div class="card plan-box">
                <div class="card-body p-4">
                    <div class="media">
                        <div class="media-body">
                            <h5>Total Cash</h5>
                            <p class="text-muted">Total here</p>
                        </div>
                        <div class="ml-3">
                            <i class="fas fa-check-double text-success"></i>
                        </div>
                    </div>
                    <div class="py-4">
                        <?php
                            $debit =0;
                            $credit =0;
                        ?>
                        <?php $__currentLoopData = $cashes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" value="<?php echo e($debit = $debit + $item->debit); ?>">
                            <input type="hidden" value="<?php echo e($credit = $credit + $item->credit); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h2><sup><small>#</small></sup> <?php echo e($credit - $debit); ?>/- <span class="font-size-13"></span></h2>
                    </div>
                    <div class="text-center plan-btn">
                        <a href="#" class="btn btn-primary btn-sm waves-effect waves-light">Show Here</a>
                    </div> 
                     
                </div>
            </div>
        </div>


        
    </div>
    <!-- end row -->

</div> <!-- container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\form\project\resources\views/back-end/dashboard/dashboard.blade.php ENDPATH**/ ?>